from Preprocess2 import Preprocess2
from IntentModel import IntentModel

p = Preprocess2(word2index_dic="C:/capstone/chatbot2_dic.bin",
                userdic="C:/capstone/user_dic.tsv")

intent = IntentModel(model_name="C:/capstone/intent_model.h5", preprocess = p)


query = "음수 인덱스 사용시 어떻게 출력되나요"
predict = intent.predict_class(query)
predict_label = intent.labels[predict]
print("="*30)
print(query)
print("의도 예측 클래스 : ", predict)
print("의도 예측 레이블 : ", predict_label)


query = "이스케이프 코드가 무엇인가요"
predict = intent.predict_class(query)
predict_label = intent.labels[predict]
print("="*30)
print(query)
print("의도 예측 클래스 : ", predict)
print("의도 예측 레이블 : ", predict_label)


query = "%가 나머지인가요?"
predict = intent.predict_class(query)
predict_label = intent.labels[predict]
print("="*30)
print(query)
print("의도 예측 클래스 : ", predict)
print("의도 예측 레이블 : ", predict_label)