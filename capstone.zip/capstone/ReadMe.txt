사용법

경로: C:\capstone

챗봇 엔진 서버 C:\capstone\chatbot

텔레그램 서버 C:\capstone\pythonProject\main

Flask API 서버 C:\capstone\chatbot_api\app

세개 서버를 작동시키고 텔레그램에서 /start를 입력해서 사용하면 됩니다.

텔레그램에서 과제제출 봇을 검색하시면 됩니다.

