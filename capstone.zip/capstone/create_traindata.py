import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from konlpy.tag import Komoran
import matplotlib.pyplot as plt
import gspread
from oauth2client.service_account import ServiceAccountCredentials

class CreateTraindata:
    def __init__(self):
        self.traindata()
        self.label_count = None

    def traindata(self):
        abc = pd.read_excel('C:/capstone/traindata생성용.xlsx')
        abc.dropna(inplace=True)
        print(f"common_sense shape => {abc.shape}")
        abc.columns
        all_data = list(abc['query']) + list(abc['answer'])
        abc_intent = set(list(abc['intent']))

        real_intent = sorted(list(abc_intent))


        label_count = len(abc_intent)
        self.label_count = label_count
        print(len(abc_intent))
        print(len(all_data))

        total = pd.DataFrame({'text': all_data})
        total.to_csv("C:/capstone/파이썬통합본데이터.csv", index=False)

        realdata = {}

        for i in range(len(abc_intent)):
            realdata[real_intent[i]] = []

        s_real_data = sorted(list(realdata))

        realdata_label = {}
        for i in range(len(abc_intent)):
            realdata_label[real_intent[i] + "_label"] = []

        s_realdata_label = sorted(list(realdata_label))

        qnadata2 = []
        for i in range(len(abc_intent)):
            intent = real_intent[i]
            a = abc.loc[abc['intent'] == intent, ['query']].values.tolist()
            b = abc.loc[abc['intent'] == intent, ['answer']].values.tolist()
            qnadata2.append([x[0] for x in a] + [x[0] for x in b])

        for i in range(len(abc_intent)):
            s_real_data[i] = qnadata2[i]

        a = 0
        for i in range(len(abc_intent)):
            print(len(qnadata2[i]))
            a = a + len(qnadata2[i])

        print("학습 총 데이터는 ", a)

        rd_label = {}

        for i in range(len(abc_intent)):
            rd_label[s_realdata_label[i]] = []

        for i in range(len(abc_intent)):
            for a in range(len(qnadata2[i])):
                rd_label[s_realdata_label[i]].append(i)

        train_dfs = []

        for i in range(len(abc_intent)):
            train_df = pd.DataFrame({'text': s_real_data[i],
                                     'label': rd_label[s_realdata_label[i]]})
            train_dfs.append(train_df)

        qnatrain_df = pd.concat(train_dfs, ignore_index=True)

        qnatrain_df.reset_index(drop=True, inplace=True)

        qnatrain_df.to_csv("C:/capstone/train_data.csv", index=False)
        data = pd.read_csv('C:/capstone/train_data.csv')
        data.shape

        tokenizer = Komoran()

        exclusion_tags = [
            'JKS', 'JKC', 'JKG', 'JKO', 'JKB', 'JKV', 'JKQ',
            'JX', 'JC',
            'SF', 'SP', 'SS', 'SE', 'SO',
            'EP', 'EF', 'EC', 'ETN', 'ETM',
            'XSN', 'XSV', 'XSA'
        ]
        data_tokenized = [[token + "/" + POS for token, POS in tokenizer.pos(text_)] for text_ in data['text']]

        f = lambda x: x in exclusion_tags

        data_list = []
        for i in range(len(data_tokenized)):
            temp = []
            for j in range(len(data_tokenized[i])):
                if f(data_tokenized[i][j].split('/')[1]) is False:
                    temp.append(data_tokenized[i][j].split('/')[0])
            data_list.append(temp)

        num_tokens = [len(tokens) for tokens in data_list]
        num_tokens = np.array(num_tokens)

        # 평균값, 최댓값, 표준편차
        print(f"토큰 길이 평균: {np.mean(num_tokens)}")
        print(f"토큰 길이 최대: {np.max(num_tokens)}")
        print(f"토큰 길이 표준편차: {np.std(num_tokens)}")

        select_length = 25

        def below_threshold_len(max_len, nested_list):
            cnt = 0
            for s in nested_list:
                if (len(s) <= max_len):
                    cnt = cnt + 1

            print('전체 샘플 중 길이가 %s 이하인 샘플의 비율: %s' % (max_len, (cnt / len(nested_list))))

        below_threshold_len(select_length, data_list)
        return
