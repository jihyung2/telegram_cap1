from Preprocess2 import Preprocess2
from tensorflow.keras import preprocessing
import pickle
import gspread
from oauth2client.service_account import ServiceAccountCredentials
import pandas as pd

scope = [
    "https://spreadsheets.google.com/feeds",
    "https://www.googleapis.com/auth/drive",
]
creds = ServiceAccountCredentials.from_json_keyfile_name(
    'C:/capstone/pythonProject/capdi-378609-2fc18c110369.json',
    scope)
client = gspread.authorize(creds)

worksheet = client.open('capstone_question_data').worksheet("AI학습용가공데이터")

data = worksheet.get_all_values()

text_column = [row[0] for row in data]
query_column = [row[1] for row in data]
answer_column = [row[2] for row in data]

print(list(set(text_column)))  # 구글 스프레드 시트에 0번 로우의 중복된값 제거 한 키워드
print(query_column)
print(answer_column)

keyword_ai = list(set(text_column))
query = list(query_column)
answer = list(answer_column)

querydata = {}
answerdata = {}
labeldata = {}
aidata = {}

train_dfs = []

for keyword in keyword_ai:
    print(keyword)
    querydata[keyword] = []
    answerdata[keyword] = []
    aidata[keyword] = []
a = 2
for keyword in keyword_ai:
    a = a + 1
    print(keyword)
    for row in data:
        if keyword == row[0]:
            aidata[keyword].append(row[1])
            aidata[keyword].append(row[2])
    print(aidata[keyword])

    len(aidata[keyword])
    labeldata[keyword] = []

    for _ in range(len(aidata[keyword])):
        labeldata[keyword].append(a)
    len(labeldata[keyword])
    print(len(labeldata[keyword]))

    train2_df = pd.DataFrame({'text': aidata[keyword],
                              'label': labeldata[keyword]})
    train_dfs.append(train2_df)

qnatrain_df = pd.concat(train_dfs, ignore_index=True)
print(qnatrain_df)


total = pd.read_csv("C:/capstone/통합본데이터.csv")

total.dropna(inplace=True)

all_data = list(total['text'])+ list(query_column)+ list(answer_column)

p = Preprocess2()
dict = []
for c in all_data:
    pos = p.pos(c)
    for k in pos:
        dict.append(k[0])

tokenizer = preprocessing.text.Tokenizer(oov_token='OOV', num_words=100000)
tokenizer.fit_on_texts(dict)
word_index = tokenizer.word_index
print(len(word_index))

f = open("C:/capstone/chatbot2_dic.bin", "wb")

try:
    pickle.dump(word_index, f)
except Exception as e:
    print(e)
finally:
    f.close()