# -*- coding: utf-8 -*-
import time
import asyncio
import telegram
import asyncio
import pymysql
from telegram.ext import run_async
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, ConversationHandler
import requests
import random
import gspread
from oauth2client.service_account import ServiceAccountCredentials
from datetime import datetime
import logging
from telegram import Update, error
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, CallbackContext

BOT_token = "6286404030:AAEUvDuYPmixLU2gnUU6LTxFuMPO03eL9xM"
BOT_NAME = '파이썬 프로그래밍 기말고사 대비 문제은행 봇'

host = "127.0.0.1"
port = 5050

user_num = {}
user_answer = {}
user_state = {}
user_freq = {}
fail_num = {}
test_num = {}
user_question = {}
user_randnum = {}

n=0
now = datetime.now()
global NUM
NUM=4

log_file = 'usage_log2.txt'

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO)

logger = logging.getLogger(__name__)

db = pymysql.connect(host='127.0.0.1', user='root', password='040416', db='qtdata', charset='utf8', port=3306)
cursor = db.cursor(pymysql.cursors.DictCursor)
bot = telegram.Bot(BOT_token)

info_message = "안녕하세요, 파이썬 프로그래밍 기말고사 대비 챗봇입니다.\n" \
               "관련사항을 공지하겠습니다.\n" \
               "1. 1시간동안 챗봇을 제공하며 문제는 랜덤으로 출제됩니다. 이중 20문제가 기말고사에 매우 유사하게 출제됩니다. \n2. 작성하시는 답안은 기록되니 꼭 풀어보시길 추천드립니다. \n3. 결과를 제공해드리진 않습니다. \n4. 학생분들의 질문내용과 강의자료를 통해 제작되었습니다.  \n5. 정답은 단어의 경우 한글로 적어주시면 됩니다. ex)튜플, 딕셔너리 등등" \
               "\n6. 함수의 경우 ()를 붙여야합니다 ex) sort()\n7. 답안을 작성하셔야지만 정답과 관계없이 다음문제로 넘어가실 수 있습니다. \n\n 내용을 모두 읽으셨으면 /next 를 입력해서 문제를 풀어주세요"

def idnameupload(update, context)-> None:
    user = update.message.from_user
    chat_id = update.message.chat_id
    user_text = update.message.text
    scope = [
        "https://spreadsheets.google.com/feeds",
        "https://www.googleapis.com/auth/drive",
    ]
    creds = ServiceAccountCredentials.from_json_keyfile_name(
        'capdi-378609-2fc18c110369.json',
        scope)
    client = gspread.authorize(creds)

    spreadsheet = client.open('capstone_question_data')
    worksheet = spreadsheet.worksheet('기말고사 예상문제')
    data = worksheet.get_all_values()

    #query = "INSERT INTO testdata (clustering, question, answer) VALUES (%s, %s, %s)"
    query = "INSERT INTO finaldata (question, answer, testnum) VALUES (%s, %s, %s)"

    for row in data:
        cursor.execute(query, (row[1], row[2], row[3]))
    context.bot.send_message(chat_id=chat_id,
                             text="학생데이터 스프레드시트 --> db 성공적으로 입력되었습니다.")
    db.commit()
    db.close()
def error_handler(update: Update, context: CallbackContext) -> None:
    """Log the error and send a message to the user."""
    logger.warning(f'Update "{update}" caused error "{context.error}"')
    try:
        raise context.error
    except error.BadRequest:
        # handle BadRequest error
        pass
    except error.TimedOut:
        # handle network connection errors
        pass
    except error.Unauthorized:
        # handle unauthorized access errors
        pass
    except error.RetryAfter as e:
        # handle throttling errors
        logger.warning(f'Throttled by Telegram: {e.retry_after} seconds')
        time.sleep(e.retry_after)
    except error.TelegramError:
        # handle all other Telegram errors
        pass
    except Exception:
        # handle all other exceptions
        pass
def starthandler(update, context)-> None:
    user = update.message.from_user
    chat_id = update.message.chat_id
    context.bot.send_message(chat_id=chat_id, text=info_message)

    global user_state
    global user_num

    if chat_id not in user_num:
        user_num[chat_id] = 0
    else:
        user_num[chat_id] = 0

    if chat_id not in user_state:
        user_state[chat_id] = "pass"


def nexthandler(update, context):
    user = update.message.from_user
    chat_id = update.message.chat_id
    user_text = update.message.text
    now = datetime.now()

    if user_state[chat_id] == "pass":
        try:
            if chat_id in user_freq:
                user_freq[chat_id].append(now)
            else:
                user_freq[chat_id] = [now]

            with open(log_file, 'a') as f:
                log_entry = f"User ID : {chat_id}, Timestamp: {now}, User Name : {user['first_name']+user['last_name']}\n "
                f.write(log_entry)

            global user_answer
            if chat_id not in user_answer:
                user_answer[chat_id] = 0
            else:
                user_answer[chat_id] = 0

            global fail_num
            if chat_id not in fail_num:
                fail_num[chat_id] = 0
            else:
                fail_num[chat_id] = 0

            global user_question
            if chat_id not in user_question:
                user_question[chat_id] = 0
            else:
                user_question[chat_id] = 0

            global user_randnum
            if chat_id not in user_randnum:
                user_randnum[chat_id] = random.randint(1,50)
            else:
                user_randnum[chat_id] = random.randint(1,50)




            sql = "SELECT question FROM finaldata WHERE testnum = %s"
            cursor.execute(sql, str(user_randnum[chat_id]))
            user_question[chat_id] = cursor.fetchone()
            print(str(chat_id) + " : " + str(user_question[chat_id]['question']))
            context.bot.send_message(chat_id=chat_id, text=str(user_question[chat_id]['question']))
            sql = "SELECT answer FROM finaldata WHERE testnum = %s"
            cursor.execute(sql, str(user_randnum[chat_id]))
            user_answer[chat_id] = cursor.fetchone()
            print(str(chat_id) + " 정답은 : " + str(user_answer[chat_id]['answer']))
            user_state[chat_id] = "close"
            db.commit()

        except:
            context.bot.send_message(chat_id=chat_id, text="...에러가 발생했습니다. /start를 다시 입력해주세요")
    else:
        context.bot.send_message(chat_id=chat_id, text="답을 입력해주세요")

def handler(update, context)-> None:
    user = update.message.from_user
    chat_id = update.message.chat_id
    user_text = update.message.text
    global user_state
    now = datetime.now()

    if user_num[chat_id] == 0:
        try:
            context.bot.send_message(chat_id=chat_id, text="/next 를 눌러 다음문제를 풀어주세요.")
            sql = "INSERT INTO examdata(id, question, answer, useranswer, timestamp) VALUES (%s, %s, %s, %s, %s)"
            cursor.execute(sql, (str(chat_id), str(user_question[chat_id]['question']), str(user_answer[chat_id]['answer']), str(user_text), str(now)))
            fail_num[chat_id] = 0
            user_state[chat_id] = "pass"
            db.commit()


        except:
            context.bot.send_message(chat_id=chat_id,
                                     text="..에러가 발생했습니다. /start를 다시 입력해주세요")

def main() -> None:
    updater = Updater(token=BOT_token, use_context=True)
    dispatcher = updater.dispatcher

    start_handler = CommandHandler('start', starthandler)
    echo_handler = MessageHandler(Filters.text & ~Filters.command, handler, run_async=True)
    next = CommandHandler('next', nexthandler, run_async=True)
    mariadb_upload = CommandHandler('mariadbupload', idnameupload)


    dispatcher.add_handler(start_handler)
    dispatcher.add_handler(echo_handler)
    dispatcher.add_error_handler(error_handler)
    dispatcher.add_handler(next)
    dispatcher.add_handler(mariadb_upload)

    updater.start_polling()
    updater.idle()

if __name__ == "__main__":
    main()